import React from "react";
import SurveyApp from "../components/Survey/surveyApp";

const SurveyAppPage = () => {
  return (
    <div>
      <SurveyApp />
    </div>
  );
};
export default SurveyAppPage;
