import React from "react";
import USer from "../components/loginPageUser/addUser/User";

const RagisterPage = () => {
  return (
    <div>
      <USer />
    </div>
  );
};

export default RagisterPage;
