import React from 'react'
import SurveyPages from '../../pages/surveyPages';
import UserFooter from '../loginPageUser/footer/footer';

const Setting = () => {
  return (
    <div>
      <SurveyPages/>
      <UserFooter/>
    </div>
  )
}
export default Setting;
