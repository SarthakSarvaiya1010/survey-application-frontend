import React from "react";
import "./footer.css";

const UserFooter = () => {
  return (
  <>
  <div className="user-footer-main"></div>
 
</>);
};
export default UserFooter;
