import React from "react";
import "../../assets/css/global.css";

const ErrorPage = () => {
  return (
    <div className="page-404">
      <h1 className="page-not-found">page not found</h1>
    </div>
  );
};
export default ErrorPage;
