// for login and supervisor and admin
export const Home = "/";
export const passwordReset = "/resetpassword";
export const passwordReset_token = "/resetpassword/:id";
export const add = "/addUser"; // *** not working
export const Survey = "/surveyPage/survey";
export const Sign = "/admin";
export const worker = "/survey/:worker";

// for ***

export const addTask = "/addTask";

// for pages
export const surveyPage = "/surveyPage";
export const dashboard = "/surveyPage/dashboard";
export const team = "/surveyPage/Team";
export const setting = "/surveyPage/setting";
