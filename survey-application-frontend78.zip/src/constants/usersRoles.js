export const userRole = {
  ADMIN: 1,
  SUPERVISOR: 2,
  WORKER: 3
};
