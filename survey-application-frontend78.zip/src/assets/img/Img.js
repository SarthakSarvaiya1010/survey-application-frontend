export { default as logo } from "./logo.png";
export { default as survey } from "./survey.png";
export { default as user } from "./user.png";
export { default as surveyUser } from "./surveyUser.jpg";
export {default as dimg} from "./dimg.png";